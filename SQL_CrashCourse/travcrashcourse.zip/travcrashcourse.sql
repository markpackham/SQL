-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 01, 2018 at 06:59 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `travcrashcourse`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `zipcode` varchar(255) DEFAULT NULL,
  `age` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `firstName`, `lastName`, `email`, `address`, `city`, `state`, `zipcode`, `age`) VALUES
(1, 'John', 'Doe', 'j@gmail.com', '55 main st', 'Boston', 'Massachusettes', '01221', 12),
(3, 'Mark', 'Packham', 'updateEmail@hotmail.com', '16 main rd', 'New York', 'New York', '61221', 13),
(4, 'Steve', 'Doe', 'steve@gmail.com', '156 river st', 'New York', 'New York', '06221', 400),
(5, 'Andy', 'Warski', 'andy@gmail.com', '6 cottage st', 'Ciatel', 'Washington', '01771', 95),
(6, 'Dave', 'Smith', 'dave@gmail.com', '2 raindow valley', 'Austin', 'Texas', '01451', 56),
(7, 'AJ', 'Styles', 'aj@gmail.com', '619 impact st', 'Gainsville', 'Georgia', '1998', 56),
(8, 'Timmy', 'Jenkins', 'tim@hotmail.com', '32 Acacia Avenue', 'Landrum', 'Virginia', '3902', 23);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `orderNumber` int(11) DEFAULT NULL,
  `productId` int(11) DEFAULT NULL,
  `customerId` int(11) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `orderDate` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `orderNumber`, `productId`, `customerId`, `age`, `orderDate`) VALUES
(1, 1, 1, 4, NULL, '2018-02-28 17:45:27'),
(2, 2, 3, 1, NULL, '2018-02-28 17:45:27'),
(3, 4, 1, 1, NULL, '2018-02-28 17:45:27'),
(4, 5, 1, 7, NULL, '2018-02-28 17:45:27'),
(5, 6, 1, 1, NULL, '2018-02-28 17:45:27'),
(6, 7, 4, 6, NULL, '2018-02-28 17:45:27'),
(7, 8, 4, 4, NULL, '2018-02-28 17:45:27'),
(8, 9, 2, 5, NULL, '2018-02-28 17:45:27');

-- --------------------------------------------------------

--
-- Stand-in structure for view `order_greater_than_4_view`
-- (See below for the actual view)
--
CREATE TABLE `order_greater_than_4_view` (
`orderNumber` int(11)
,`productId` int(11)
,`customerId` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`) VALUES
(1, 'Prod one,', 10),
(2, 'Prod two,', 100),
(3, 'Prod three,', 1000),
(4, 'Prod four,', 90),
(5, 'Prod five,', 2),
(6, 'Prod six,', 13210);

-- --------------------------------------------------------

--
-- Stand-in structure for view `replace_order_less_5_view`
-- (See below for the actual view)
--
CREATE TABLE `replace_order_less_5_view` (
`orderNumber` int(11)
,`productId` int(11)
,`customerId` int(11)
);

-- --------------------------------------------------------

--
-- Structure for view `order_greater_than_4_view`
--
DROP TABLE IF EXISTS `order_greater_than_4_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `order_greater_than_4_view`  AS  select `orders`.`orderNumber` AS `orderNumber`,`orders`.`productId` AS `productId`,`orders`.`customerId` AS `customerId` from `orders` where (`orders`.`orderNumber` > 4) ;

-- --------------------------------------------------------

--
-- Structure for view `replace_order_less_5_view`
--
DROP TABLE IF EXISTS `replace_order_less_5_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `replace_order_less_5_view`  AS  select `orders`.`orderNumber` AS `orderNumber`,`orders`.`productId` AS `productId`,`orders`.`customerId` AS `customerId` from `orders` where (`orders`.`orderNumber` < 4) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customerId` (`customerId`),
  ADD KEY `productId` (`productId`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customerId`) REFERENCES `customers` (`id`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`productId`) REFERENCES `products` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
